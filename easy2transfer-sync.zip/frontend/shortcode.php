<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [e2t_members]
 * ----------------------------------------------------------
 * Rendert Mitgliederkarten im Frontend mit Styles & JS
 */
add_shortcode('e2t_members', function ($atts) {

  // 🔧 Attribute (optional, später erweiterbar)
  $atts = shortcode_atts([], $atts, 'e2t_members');

  // 🧩 Sicherstellen, dass Renderer vorhanden ist
  if (!function_exists('e2t_render_members')) {
    return '<p>❌ Rendering-Funktion nicht gefunden. Bitte überprüfe includes/renderer.php.</p>';
  }

  // 🎨 Frontend-Assets einbinden
  wp_enqueue_style(
    'e2t-frontend-style',
    E2T_URL . 'frontend/assets/frontend.css',
    [],
    '1.0'
  );

  wp_enqueue_script(
    'e2t-frontend-script',
    E2T_URL . 'frontend/assets/frontend.js',
    ['jquery'],
    '1.0',
    true
  );

  // 💡 Renderer aufrufen (HTML der Mitgliederkarten)
  $output = e2t_render_members();

  // 🔄 Wrapper für Konsistenz
  return '<div class="e2t-members-wrapper">' . $output . '</div>';
});
