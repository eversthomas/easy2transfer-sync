<?php
if (!defined('ABSPATH')) exit;

/**
 * Platzhalter für zukünftige AJAX- oder REST-Endpunkte
 * Beispiel: Suche, Filter, Pagination
 */

// Beispiel-Struktur für spätere Nutzung
/*
add_action('wp_ajax_e2t_filter_members', function() {
  // hier Filterlogik
});
add_action('wp_ajax_nopriv_e2t_filter_members', function() {
  // öffentlich aufrufbar
});
*/