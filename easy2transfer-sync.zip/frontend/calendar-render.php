<?php
if (!defined('ABSPATH')) exit;

/**
 * ------------------------------------------------------------
 * 📅 FRONTEND-KALENDER (Mehrere Kalender)
 * ------------------------------------------------------------
 */

add_shortcode('e2t_kalender', function ($atts) {

    $atts = shortcode_atts([
        'id'    => '',
        'limit' => 10,
    ], $atts);

    $id = sanitize_title($atts['id']);
    $limit = intval($atts['limit']);

    $calendars = get_option('e2t_calendars', []);
    $calendar = null;

    foreach ($calendars as $c) {
        if ($c['id'] === $id) {
            $calendar = $c;
            break;
        }
    }

    if (!$calendar || empty($calendar['url'])) {
        return '<p>⚠️ Kein gültiger Kalender gefunden.</p>';
    }

    $cache_file = E2T_DATA . "calendar-cache-{$id}.json";
    $cache_lifetime = 6 * HOUR_IN_SECONDS;

    if (file_exists($cache_file) && (time() - filemtime($cache_file)) < $cache_lifetime) {
        $events = json_decode(file_get_contents($cache_file), true);
    } else {
        $events = e2t_parse_ics($calendar['url'], $calendar['max']);
        file_put_contents($cache_file, json_encode($events, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    if (empty($events)) {
        return '<p>Keine kommenden Termine gefunden.</p>';
    }

    // Filter: nur kommende Events
    $today = strtotime('today');
    $events = array_filter($events, fn($e) => strtotime($e['start']) >= $today);

    ob_start(); ?>
    <div class="e2t-calendar" data-limit="<?php echo esc_attr($limit); ?>">
        <h2><?php echo esc_html($calendar['name']); ?></h2>
        <div class="e2t-calendar-grid">
            <?php foreach ($events as $i => $e): ?>
            <div class="e2t-event-card<?php echo $i >= $limit ? ' hidden' : ''; ?>">
                <div class="e2t-event-date"><?php echo date_i18n('d.m.Y', strtotime($e['start'])); ?></div>
                <h3 class="e2t-event-title"><?php echo esc_html($e['title']); ?></h3>
                <?php if (!empty($e['location'])): ?>
                    <div class="e2t-event-location"><?php echo esc_html($e['location']); ?></div>
                <?php endif; ?>
                <?php if (!empty($e['html_description']) || !empty($e['description'])): ?>
                    <button class="e2t-readmore">Weiterlesen</button>
                    <div class="e2t-event-full hidden"><?php echo wp_kses_post($e['html_description'] ?: nl2br(esc_html($e['description']))); ?></div>
                <?php endif; ?>
                <?php if (!empty($e['url'])): ?>
                    <a href="<?php echo esc_url($e['url']); ?>" class="e2t-event-link" target="_blank">Zur Veranstaltung</a>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <?php if (count($events) > $limit): ?>
        <button class="e2t-load-more">Mehr anzeigen</button>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
});

/**
 * ------------------------------------------------------------
 * 🧩 ICS PARSER
 * ------------------------------------------------------------
 */
function e2t_parse_ics($url, $max = 200)
{
    $response = wp_remote_get($url);
    if (is_wp_error($response)) return [];

    $lines = explode("\n", wp_remote_retrieve_body($response));
    $events = [];
    $event = [];

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === 'BEGIN:VEVENT') $event = [];
        elseif ($line === 'END:VEVENT') {
            if (!empty($event)) $events[] = $event;
            if (count($events) >= $max) break;
        } elseif (strpos($line, 'SUMMARY:') === 0) $event['title'] = substr($line, 8);
        elseif (strpos($line, 'DTSTART') === 0) $event['start'] = e2t_parse_datetime($line);
        elseif (strpos($line, 'DTEND') === 0) $event['end'] = e2t_parse_datetime($line);
        elseif (strpos($line, 'LOCATION:') === 0) $event['location'] = substr($line, 9);
        elseif (strpos($line, 'DESCRIPTION:') === 0) $event['description'] = substr($line, 12);
        elseif (strpos($line, 'X-ALT-DESC') === 0) $event['html_description'] = substr($line, strpos($line, ':') + 1);
        elseif (strpos($line, 'URL:') === 0) $event['url'] = substr($line, 4);
        elseif (strpos($line, 'CLASSIFICATION:') === 0) $event['category'] = substr($line, 15);
    }

    return $events;
}

function e2t_parse_datetime($line)
{
    if (preg_match('/:(\d{8}T\d{6})/', $line, $m)) {
        return date('Y-m-d H:i:s', strtotime($m[1]));
    }
    return '';
}

// ------------------------------------------------------------
// 💅 Skript & CSS einbinden
// ------------------------------------------------------------
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('e2t-calendar', E2T_URL . 'frontend/assets/calendar.css', [], '1.0');
    wp_enqueue_script('e2t-calendar-js', E2T_URL . 'frontend/assets/calendar.js', ['jquery'], '1.0', true);
});