<?php if (!defined('ABSPATH')) exit; ?>

<div class="wrap e2t-fields">

  <!-- 🔹 LINKER SIDEBAR-BEREICH WIRD PER JS EINGEFÜGT -->

  <div class="e2t-mainarea">
      
      <!-- Kopfbereich gehört in den Mainarea -->
      <div class="e2t-header">
        <h2>EasyVerein – Feldverwaltung</h2>
        <p>Shortcode: <strong>[e2t_members]</strong></p>
        <p>Hier kannst du festlegen, welche Felder im Frontend angezeigt werden sollen, und ob sie oberhalb oder unterhalb des „Weiterlesen“-Buttons erscheinen.</p>
        <div id="e2t-message" class="notice-inline"></div>
      </div>

      <!-- FELDER-BEREICHE (werden von JS neu befüllt) -->
      <div class="e2t-sections">

        <div class="e2t-section" data-area="above">
          <h3>🟩 Über dem Button</h3>
          <div id="e2t-above" class="e2t-sortable"></div>
        </div>

        <div class="e2t-section" data-area="below">
          <h3>🟦 Unter dem Button</h3>
          <div id="e2t-below" class="e2t-sortable"></div>
        </div>

        <div class="e2t-section" data-area="unused">
          <h3>⬜ Nicht gebraucht</h3>
          <div id="e2t-unused" class="e2t-sortable"></div>
        </div>

      </div>

      <!-- Aktionen -->
      <div class="e2t-actions">
        <button id="e2t-save-fields" class="button button-primary">💾 Änderungen speichern</button>
        <button id="e2t-reload-fields" class="button">🔄 Neu laden</button>
      </div>

  </div> <!-- END .e2t-mainarea -->

</div> <!-- END .wrap -->
