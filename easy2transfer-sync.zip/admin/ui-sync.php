<?php
if (!defined('ABSPATH')) exit;

/**
 * Sync-Tab: Verwaltung der Easy2Transfer-Synchronisierung
 * (ausgelagert aus easy2transfer-sync.php)
 */
?>

<form method="post" class="e2t-sync-form">
    <table class="form-table">
        <tr>
            <th><label for="e2t_token">API-Token</label></th>
            <td>
                <input type="text" id="e2t_token" name="e2t_token"
                    value="<?php echo esc_attr(get_option('e2t_api_token', '')); ?>"
                    style="width:400px;">
            </td>
        </tr>
    </table>
    <p>
        <button type="submit" class="button">Token speichern</button>
        &nbsp;
        <!-- direkt hier drunter ent-kommentieren, falls alle Mitglieder abgerufen werden können sollen -->
        <!-- <button disabled type="button" id="e2tStart" class="button button-primary">🔄 Alle Mitglieder abrufen</button>
        &nbsp; -->
        <button type="button" id="e2tStartConsent" class="button button-secondary">✅ Nur Mitglieder mit Consent abrufen</button>
    </p>
</form>

<div id="e2tProgress" class="e2t-progress" style="margin-top:20px;padding:10px;border:1px solid #ccc;display:none;">
    <div style="margin-bottom:8px;">Gesamtfortschritt:</div>
    <div id="e2tBar" style="height:20px;background:#eee;border-radius:5px;margin-bottom:10px;">
        <div id="e2tBarInner" style="height:20px;width:0;background:#0073aa;border-radius:5px;"></div>
    </div>

    <div style="margin-bottom:8px;">Aktueller Schritt:</div>
    <div id="e2tBar2" style="height:10px;background:#f0f0f0;border-radius:5px;">
        <div id="e2tBarInner2" style="height:10px;width:0;background:#00a32a;border-radius:5px;"></div>
    </div>

    <p id="e2tStatus" style="margin-top:8px;font-weight:bold;">Bereit.</p>
</div>

<script>
    jQuery(function($) {
        const btnAll = $('#e2tStart');
        const btnConsent = $('#e2tStartConsent');
        const bar1 = $('#e2tBarInner');
        const bar2 = $('#e2tBarInner2');
        const status = $('#e2tStatus');
        const box = $('#e2tProgress');

        function poll() {
          $.get(ajaxurl, { action: 'e2t_status' }, function (resp) {
            if (!resp.success) return;
            const s = resp.data;
            bar1.css('width', (s.progress || 0) + '%');
            status.text(s.message || '');
            if (s.state === 'running') setTimeout(poll, 3000);
          });
        }

		// =====================================================
        // 🔁  Automatische Statusaktualisierung alle 5 Sekunden
        // =====================================================
        setInterval(function() {
          $.get(ajaxurl, { action: 'e2t_status' }, function (resp) {
            if (!resp.success) return;
            const s = resp.data;
            if (!s) return;

            // Fortschrittsbalken
            $('#e2tBarInner').css('width', (s.progress || 0) + '%');
            $('#e2tStatus').text(s.message || '');

            // Wenn Sync fertig, Buttons wieder aktivieren
            if (s.state === 'done') {
              $('#e2tStartConsent').prop('disabled', false).text('✅ Nur Mitglieder mit Consent abrufen');
            }
          });
        }, 5000);


        function startSync(action, btn) {
            btn.prop('disabled', true).text('Starte...');
            box.show();
            status.text('Plane WP-Cron Event ...');

            $.post(ajaxurl, {
                action: action
            }, function(resp) {
                if (resp.success) {
                    status.text('Sync gestartet ...');
                    setTimeout(poll, 5000);
                } else {
                    status.text('Fehler: ' + (resp.data.error || 'Unbekannt'));
                    btn.prop('disabled', false).text(btn.data('label'));
                }
            });
        }

        btnAll.data('label', '🔄 Alle Mitglieder abrufen');
        btnConsent.data('label', '✅ Nur Mitglieder mit Consent abrufen');

        btnAll.on('click', function() {
            startSync('e2t_start', btnAll);
        });

        btnConsent.on('click', function() {
            startSync('e2t_start_consent', btnConsent);
        });

        // Autostart bei laufendem Sync
        $.get(ajaxurl, {
            action: 'e2t_status'
        }, function(resp) {
            if (resp.success && resp.data.state === 'running') {
                box.show();
                btnAll.prop('disabled', true).text('Läuft ...');
                btnConsent.prop('disabled', true).text('Läuft ...');
                poll();
            }
        });
    });
</script>