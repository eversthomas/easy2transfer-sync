<?php

/**
 * Plugin Name: Easy2Transfer Sync
 * Description: Exportiert Mitglieder- und Kontaktdaten aus EasyVerein (API v2.0) und schreibt sie lokal in /.
 * Version: 2.9
 * Author: Thomas Evers / ChatGPT Helper
 */

if (!defined('ABSPATH')) exit;

/**
 * ------------------------------------------------------------
 *  🔧 BASIS-KONSTANTEN (einheitlich für alle Module)
 * ------------------------------------------------------------
 */
if (!defined('E2T_DIR'))  define('E2T_DIR', plugin_dir_path(__FILE__));
if (!defined('E2T_URL'))  define('E2T_URL', plugin_dir_url(__FILE__));

$upload_dir = wp_upload_dir();

// 📁 Uploads-Verzeichnisse & URLs
if (!defined('E2T_UPLOADS_DIR')) define('E2T_UPLOADS_DIR', trailingslashit($upload_dir['basedir']) . 'easy2transfer-sync/');
if (!defined('E2T_UPLOADS_URL')) define('E2T_UPLOADS_URL', trailingslashit($upload_dir['baseurl']) . 'easy2transfer-sync/');

// 📄 Daten- und Bildpfade
if (!defined('E2T_DATA')) define('E2T_DATA', E2T_UPLOADS_DIR);
if (!defined('E2T_IMG'))  define('E2T_IMG', trailingslashit(E2T_UPLOADS_DIR) . 'img/');

// 🔒 Sicherstellen, dass Ordner existieren
if (!file_exists(E2T_DATA)) wp_mkdir_p(E2T_DATA);
if (!file_exists(E2T_IMG))  wp_mkdir_p(E2T_IMG);

/**
 * ------------------------------------------------------------
 *  🔩 CORE-FUNKTIONEN & CRON
 * ------------------------------------------------------------
 */
require_once E2T_DIR . 'sync/api-core.php';
require_once E2T_DIR . 'sync/api-core-consent.php';
require_once E2T_DIR . 'sync/cron.php';

require_once E2T_DIR . 'admin/calendar-handler.php';

/**
 * ------------------------------------------------------------
 *  🌐 FRONTEND-RENDERING
 * ------------------------------------------------------------
 */
require_once E2T_DIR . 'frontend/renderer.php';
require_once E2T_DIR . 'frontend/shortcode.php';
require_once E2T_DIR . 'frontend/ajax-endpoints.php';

require_once E2T_DIR . 'frontend/calendar-render.php';
// Kalender-Modul
require_once E2T_DIR . 'admin/calendar-handler.php';
require_once E2T_DIR . 'frontend/calendar-render.php';

/**
 * ------------------------------------------------------------
 *  🧩 ADMIN-INTERFACE (Tabs, Sync, Felder, Kalender)
 * ------------------------------------------------------------
 *  UI wird über Callback geladen, um Header-Warnungen zu vermeiden.
 */
add_action('admin_menu', function () {
    add_menu_page(
        'Easy2Transfer Sync',
        'Easy2Transfer Sync',
        'manage_options',
        'easy2transfer-sync',
        'e2t_admin_page',
        'dashicons-update-alt',
        80
    );
});

/**
 * ------------------------------------------------------------
 *  🧠 FELDERVERWALTUNG (CustomField-Konfiguration)
 * ------------------------------------------------------------
 */
require_once E2T_DIR . 'admin/fields-handler.php';

/**
 * ------------------------------------------------------------
 *  🎨 ADMIN-ASSETS: Styles & Scripts
 * ------------------------------------------------------------
 */
add_action('admin_enqueue_scripts', function ($hook) {

    // Nur auf der Plugin-Seite laden
    if (strpos($hook, 'easy2transfer-sync') === false) {
        return;
    }

    /**
     * 🧩 Basis-CSS für das Admin-UI
     */
    wp_enqueue_style(
        'e2t-admin-style',
        E2T_URL . 'admin/assets/admin.css',
        [],
        '1.0'
    );

    /**
     * 🧩 Neue Sidebar-CSS
     */
    wp_enqueue_style(
        'e2t-sidebar-style',
        E2T_URL . 'admin/assets/E2t-sidebar.css',
        [],
        time() // verhindert Cache während der Entwicklung
    );

    /**
     * 🧩 Haupt-JS (Admin Tabs, UI etc.)
     */
    wp_enqueue_script(
        'e2t-admin-script',
        E2T_URL . 'admin/assets/ui.js',
        ['jquery'],
        '1.0',
        true
    );

    /**
     * 🧩 Sortable + Felderverwaltung
     */
    wp_enqueue_script(
        'e2t-sortable',
        E2T_URL . 'admin/vendor/Sortable.min.js',
        [],
        '1.15',
        true
    );

    /**
     * 🧩 Neue Sidebar-Felderverwaltung (Sidebar, Filter, Suche)
     */
    wp_enqueue_script(
        'e2t-fields-sidebar',
        E2T_URL . 'admin/assets/ui-felder-sidebar.js',
        ['jquery', 'e2t-sortable'],
        time(), // während Entwicklung Cache verhindern
        true
    );

    wp_localize_script('e2t-fields-sidebar', 'e2t_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('e2t_felder_nonce')
    ]);


    /**
     * 🔑 AJAX-Variablen bereitstellen
     */
    wp_localize_script('e2t-fields-script', 'e2t_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('e2t_felder_nonce')
    ]);
});

/**
 * ------------------------------------------------------------
 *  🧾 ADMIN CALLBACK
 * ------------------------------------------------------------
 */
function e2t_admin_page()
{
    if (!current_user_can('manage_options')) return;

    // Token speichern
    if (isset($_POST['e2t_token'])) {
        update_option('e2t_api_token', sanitize_text_field($_POST['e2t_token']));
        echo '<div class="updated"><p>Token gespeichert.</p></div>';
    }

    // Admin-UI laden
    require_once E2T_DIR . 'admin/ui-main.php';
}

/**
 * ------------------------------------------------------------
 *  🔁 AJAX: SYNC STARTEN (FULL & CONSENT)
 * ------------------------------------------------------------
 */
add_action('wp_ajax_e2t_start', function () {
    if (!current_user_can('manage_options')) wp_send_json_error(['error' => 'Keine Berechtigung']);
    wp_schedule_single_event(time() + 2, 'e2t_run_cron');
    e2t_update_status(0, 0, 'Warte auf WP-Cron ...', 'scheduled');

    if (function_exists('spawn_cron')) {
        spawn_cron();
    } else {
        wp_remote_post(site_url('wp-cron.php'));
    }

    wp_send_json_success(['msg' => 'Sync geplant']);
});

add_action('wp_ajax_e2t_start_consent', function () {
    if (!current_user_can('manage_options')) wp_send_json_error(['error' => 'Keine Berechtigung']);

    // aktuellen Durchlauf auslesen
    $part = get_option('e2t_current_part', 1);
    $offset = ($part - 1) * 200;

    e2t_update_status(0, 0, "Starte Durchlauf $part ...", 'running');
    $result = e2t_run_consent_dump($offset, 200);

    if (isset($result['ok'])) {
        $msg = "✅ Durchlauf $part abgeschlossen";
        $next = $part + 1;
        if ($next <= 3) {
            update_option('e2t_current_part', $next);
            $msg .= " – Bitte Sync erneut starten für Durchlauf $next";
        } else {
            delete_option('e2t_current_part');
            $msg .= " – Alle Durchläufe abgeschlossen!";
        }
        e2t_update_status(100, 100, $msg, 'done');
        wp_send_json_success(['msg' => $msg]);
    }

    wp_send_json_error(['error' => $result['error'] ?? 'Unbekannter Fehler']);
});


/**
 * ------------------------------------------------------------
 *  📊 AJAX: STATUS ABRUFEN
 * ------------------------------------------------------------
 */
add_action('wp_ajax_e2t_status', function () {
    $file = E2T_DATA . 'status.json';
    if (!file_exists($file)) {
        wp_send_json_success(['state' => 'idle', 'progress' => 0, 'message' => 'Kein Status.']);
    }
    $data = json_decode(file_get_contents($file), true);
    wp_send_json_success($data ?: ['state' => 'unknown', 'progress' => 0]);
});